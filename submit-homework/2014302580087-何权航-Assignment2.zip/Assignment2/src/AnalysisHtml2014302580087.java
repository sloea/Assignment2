import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class AnalysisHtml2014302580087 {
	 String name=new String();
	 String summary[]=new String[100];
	 String direction=new String();
	 String email=new String();
	 String phonenumber=new String();

	public AnalysisHtml2014302580087() throws IOException {
		// TODO �Զ����ɵĹ��캯�����
		File input = new File("��ʦ��ҳ.html");
		Document doc= Jsoup.parse(input, "UTF-8", "");
		//��ȡ����
		Elements namehtml = doc.select("h3");
		name=namehtml.text();
		//System.out.print(name);
		//
		Elements wordhtml = doc.select("p");
		//summary=wordhtml.text();
		//System.out.print(summary);
		//��ȡ�绰����
		Pattern pattern=Pattern.compile("[0-9]{3}-[0-9]{8}��[0-9]{8}");
		Matcher matcher=pattern.matcher(wordhtml.text());
		if(matcher.find()){
			phonenumber=matcher.group();
		}
		//System.out.print(phonenumber);
		//��ȡ�ʼ���ַ
		Pattern pattern1=Pattern.compile("[a-z]+@[a-z]{3}.[a-z]{3}.[a-z]{2}; [a-z]+@[a-z]{7}.[a-z]{3}");
		Matcher matcher1=pattern1.matcher(wordhtml.text());
		if(matcher1.find()){
			email=matcher1.group();
		}
		//System.out.print(email);
		//��ȡ�о�����
		Pattern pattern2=Pattern.compile("[\u4e00-\u9fa5]{8}");
		Matcher matcher2=pattern2.matcher(wordhtml.text());
		if(matcher2.find()){
			direction=matcher2.group();
		}
		//System.out.print(direction);
		//��ȡ���˼��
		Pattern pattern3=Pattern.compile("[0-9]{4}.[0-9]{2}��[0-9]{4}.[0-9]{2} [\u4e00-\u9fa5]{17}");
		Matcher matcher3=pattern3.matcher(wordhtml.text());
		if(matcher3.find()){
			summary[1]=matcher3.group();
		}
		//System.out.print(summary);
		Pattern pattern4=Pattern.compile("[0-9]{4}.[0-9]{2}��[0-9]{4}.[0-9]{2} [\u4e00-\u9fa5]{17}��[\u4e00-\u9fa5]{2}��[\u4e00-\u9fa5]{5}��");
		Matcher matcher4=pattern4.matcher(wordhtml.text());
		if(matcher4.find()){
			summary[2]=matcher4.group();
		}
		Pattern pattern5=Pattern.compile("[0-9]{4}.[0-9]{2}��[0-9]{4}.[0-9]{2} [\u4e00-\u9fa5]{9}��[A-Z]{4}[\u4e00-\u9fa5]{2}��[\u4e00-\u9fa5]{4}��[A-Z][a-z]{8} [A-Z][a-z]{3}[\u4e00-\u9fa5]{2}��");
		Matcher matcher5=pattern5.matcher(wordhtml.text());
		if(matcher5.find()){
			summary[3]=matcher5.group();
		}
		Pattern pattern6=Pattern.compile("[0-9]{4}.[0-9]{2}��[0-9]{4}.[0-9]{2} [\u4e00-\u9fa5]{13}��[\u4e00-\u9fa5]{3}/[\u4e00-\u9fa5]{5}��[\u4e00-\u9fa5]{6}");
		Matcher matcher6=pattern6.matcher(wordhtml.text());
		if(matcher6.find()){
			summary[4]=matcher6.group();
		}
		Pattern pattern7=Pattern.compile("[0-9]{4}.[0-9]{2}��[\u4e00-\u9fa5]{2}");
		Matcher matcher7=pattern7.matcher(wordhtml.text());
		if(matcher7.find()){
			summary[5]=matcher7.group();
		}
		//System.out.print(summary[5]);
			
	}

	public void OutputFile() throws IOException {
		// TODO �Զ����ɵķ������
		FileWriter out=new FileWriter("��ʦ��ҳ.txt");
		out.write("������"+name+"\r\n");
		out.write("E-mail��"+email+"\r\n");
		out.write("�绰���룺"+phonenumber+"\r\n");
		out.write("�о�����"+direction+"\r\n");
		out.write("���˼�飺\r\n"+summary[1]+"\r\n"+summary[2]+"\r\n"+summary[3]+"\r\n"+summary[4]+"\r\n"+summary[5]);
		out.close();
	}

}
