import java.io.File;
import java.io.IOException;


public class HomeWork2014302580087 {

	public HomeWork2014302580087() {
		// TODO �Զ����ɵĹ��캯�����
	}
	
	
	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie";
		HttpRequest response=HttpRequest.get(url);
		String filename="��ʦ��ҳ.html";
		if(response.ok()){
			response.receive(new File(filename));
			//System.out.println("ok");
		}
		AnalysisHtml2014302580087 analysishtml=new AnalysisHtml2014302580087();
		analysishtml.OutputFile();
		}
		
	}
	


